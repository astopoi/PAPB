package com.example.bab6.ui.home

import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.ViewModel
import com.example.bab6.data.model.Student
import com.example.bab6.data.repository.StudentRepository

class HomeViewModel(
    private val repository: StudentRepository
) : ViewModel() {
    var uiState by mutableStateOf(HomeUiState())
        private set

    private var requestVersion = 0
    private var lastSubmittedQuery = ""

    init { loadStudents() }

    fun onSearchQueryChange(query: String) {
        uiState = uiState.copy(searchQuery = query)
    }

    fun loadStudents() = fetchStudents("")

    fun searchStudents() = fetchStudents(uiState.searchQuery.trim())

    fun retry() = fetchStudents(lastSubmittedQuery)

    private fun fetchStudents(query: String) {
        lastSubmittedQuery = query
        val version = ++requestVersion
        uiState = uiState.copy(isLoading = true, errorMessage = null)
        val callback: (Result<List<Student>>) -> Unit = { result ->
            if (version == requestVersion) {
                result.onSuccess { students ->
                    uiState = uiState.copy(students = students, isLoading = false)
                }.onFailure { error ->
                    uiState = uiState.copy(
                        isLoading = false,
                        errorMessage = error.message ?: "Gagal mengambil data"
                    )
                }
            }
        }
        if (query.isBlank()) {
            repository.getStudents(callback)
        } else {
            repository.searchStudents(query, callback)
        }
    }
}
