package com.example.bab6.ui.home

import com.example.bab6.data.model.Student
import com.example.bab6.data.repository.StudentRepository
import org.junit.Assert.*
import org.junit.Test

class HomeViewModelTest {
    private class FakeRepository : StudentRepository {
        val queries = mutableListOf<String>()
        val callbacks = mutableListOf<(Result<List<Student>>) -> Unit>()
        override fun getStudents(callback: (Result<List<Student>>) -> Unit) {
            queries.add("")
            callbacks.add(callback)
        }
        override fun searchStudents(query: String, callback: (Result<List<Student>>) -> Unit) {
            queries.add(query)
            callbacks.add(callback)
        }
        override fun getStudent(id: Int, callback: (Result<Student>) -> Unit) = Unit
    }

    @Test fun editingDoesNotSearchAndBlankSubmissionLoadsInitialList() {
        val repository = FakeRepository()
        val model = HomeViewModel(repository)
        model.onSearchQueryChange(" John ")
        assertEquals(listOf(""), repository.queries)
        model.searchStudents()
        assertEquals(listOf("", "John"), repository.queries)
        model.onSearchQueryChange("   ")
        model.searchStudents()
        assertEquals(listOf("", "John", ""), repository.queries)
    }

    @Test fun failurePreservesQueryAndRetryRepeatsSubmittedSearch() {
        val repository = FakeRepository()
        val model = HomeViewModel(repository)
        model.onSearchQueryChange("John")
        model.searchStudents()
        assertTrue(model.uiState.isLoading)
        repository.callbacks.last()(Result.failure(Exception("Offline")))
        assertFalse(model.uiState.isLoading)
        assertEquals("Offline", model.uiState.errorMessage)
        assertEquals("John", model.uiState.searchQuery)
        model.onSearchQueryChange("Emily")
        model.retry()
        assertEquals("John", repository.queries.last())
        assertNull(model.uiState.errorMessage)
    }

    @Test fun olderResponseCannotOverwriteLatestSearchResult() {
        val repository = FakeRepository()
        val model = HomeViewModel(repository)
        model.onSearchQueryChange("John")
        model.searchStudents()
        val student = Student(42, "John", "john@example.com", "University")
        repository.callbacks.last()(Result.success(listOf(student)))
        repository.callbacks.first()(Result.success(emptyList()))
        assertEquals(listOf(student), model.uiState.students)
        assertFalse(model.uiState.isLoading)
    }
}
